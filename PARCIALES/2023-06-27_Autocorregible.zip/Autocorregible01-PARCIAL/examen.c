#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "examen.h"


int _contarPalabras(const char* nomArc, char* palMasLarga, int* cantVeces)
{
    return 0;
}

void* _bbinaria(const void *clave, const void *vec, size_t ce, size_t tam, int cmp(const void *, const void *))
{
    return NULL;
}


int _sumTrianDerEntreDiag(int mat[][MAX_COL], int filas)
{
    return 0;
}

int _sumTrianInfEntreDiag(int mat[][MAX_COL], int filas)
{
    return 0;
}

